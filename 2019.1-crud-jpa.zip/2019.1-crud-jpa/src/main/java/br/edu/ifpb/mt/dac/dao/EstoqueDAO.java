package br.edu.ifpb.mt.dac.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import br.edu.ifpb.mt.dac.entities.Estoque;
import br.edu.ifpb.mt.dac.entities.Gerente;
import br.edu.ifpb.mt.dac.entities.Pessoa;
import br.edu.ifpb.mt.dac.entities.User;


public class EstoqueDAO extends DAO{
	
	public void save(Estoque estoque) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		try {
			em.persist(estoque);
			transaction.commit();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			if (transaction.isActive()) {
				transaction.rollback();
			}
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar salvar estoque.", pe);
		} finally {
			em.close();
		}
	}
	public Estoque update(Estoque estoque) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		Estoque resultado = estoque;
		try {
			resultado = em.merge(estoque);
			transaction.commit();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			if (transaction.isActive()) {
				transaction.rollback();
			}
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar atualizar o usuário.", pe);
		} finally {
			em.close();
		}
		return resultado;
	}
	public void delete(Estoque estoque) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		try {
			estoque = em.find(Estoque.class, estoque.getId());
			em.remove(estoque);
			transaction.commit();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			if (transaction.isActive()) {
				transaction.rollback();
			}
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar remover o Gerente.", pe);
		} finally {
			em.close();
		}
	}
	public Estoque getByID(int estoqueID) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		Estoque resultado = null;
		try {
			resultado = em.find(Estoque.class, estoqueID);
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar recuperar o Gerente com base no ID.", pe);
		} finally {
			em.close();
		}
		return resultado;
	}
	
	public List<Estoque> getAll() throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		List<Estoque> resultado = null;
		try {
			TypedQuery<Estoque> query = em.createQuery("SELECT u FROM Estoque u", Estoque.class);
			resultado = query.getResultList();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar recuperar todos os usuários.", pe);
		} finally {
			em.close();
		}
		return resultado;
	}
	
	public boolean existe() {
		EntityManager em = getEntityManager();
		if(em.find(Estoque.class, 1) != null) {
			return true;	
		}
		return false;
	}
}
	

