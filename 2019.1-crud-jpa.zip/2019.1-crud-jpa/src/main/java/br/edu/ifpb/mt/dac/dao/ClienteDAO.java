package br.edu.ifpb.mt.dac.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import br.edu.ifpb.mt.dac.entities.Cliente;



public class ClienteDAO extends DAO{
	
	
	public void save(Cliente cliente) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		try {
			em.persist(cliente);
			transaction.commit();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			if (transaction.isActive()) {
				transaction.rollback();
			}
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar salvar o Cliente.", pe);
		} finally {
			em.close();
		}
	}
	
	public Cliente getByID(int clienteID) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		Cliente resultado = null;
		try {
			resultado = em.find(Cliente.class, clienteID);
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar recuperar o Cliente com base no ID.", pe);
		} finally {
			em.close();
		}
		return resultado;
	}
	
	public Cliente update(Cliente cliente) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		Cliente resultado = cliente;
		try {
			resultado = em.merge(cliente);
			transaction.commit();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			if (transaction.isActive()) {
				transaction.rollback();
			}
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar atualizar o Cliente.", pe);
		} finally {
			em.close();
		}
		return resultado;
	}
	public void delete(Cliente cliente) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		try {
			cliente = em.find(Cliente.class, cliente.getId());
			em.remove(cliente);
			transaction.commit();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			if (transaction.isActive()) {
				transaction.rollback();
			}
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar remover o Cliente.", pe);
		} finally {
			em.close();
		}
	}
	public List<Cliente> getAll() throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		List<Cliente> resultado = null;
		try {
			TypedQuery<Cliente> query = em.createQuery("SELECT u FROM User u", Cliente.class);
			resultado = query.getResultList();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar recuperar todos os clientes.", pe);
		} finally {
			em.close();
		}
		return resultado;
	}

}
