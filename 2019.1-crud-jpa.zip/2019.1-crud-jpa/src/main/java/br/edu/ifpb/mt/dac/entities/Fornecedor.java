package br.edu.ifpb.mt.dac.entities;

public class Fornecedor {

}
