package br.edu.ifpb.mt.dac.entities;

public class Funcionario extends Pessoa{
	
}
