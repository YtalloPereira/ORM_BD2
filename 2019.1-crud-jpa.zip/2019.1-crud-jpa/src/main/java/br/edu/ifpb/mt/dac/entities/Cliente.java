package br.edu.ifpb.mt.dac.entities;

public class Cliente extends Pessoa{
	
	public Cliente() {
		
	}
	
	
}
