package br.edu.ifpb.mt.dac.entities;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "TB_CLIENTE")
@DiscriminatorValue("Cliente")
public class Cliente extends Pessoa{
	
	private static final long serialVersionUID = 8994196307629312707L;
	
	public Cliente() {
		
	}

}
