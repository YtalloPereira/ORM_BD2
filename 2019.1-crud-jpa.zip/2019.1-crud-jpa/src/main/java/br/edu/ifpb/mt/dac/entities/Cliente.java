package br.edu.ifpb.mt.dac.entities;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;


@Entity
@DiscriminatorValue("Cliente")
public class Cliente extends Pessoa{
	
	private static final long serialVersionUID = 584896475683372912L;	
		
	public Cliente() {
		
	}

	
	
	
	@Override
	public int hashCode() {
		return super.hashCode();
	}




	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		return true;
	}




	@Override
	public String toString() {
		
		return "Tipo: Cliente \n"+super.toString();
	}

}
