package br.edu.ifpb.mt.dac.entities;

public enum Sexo {
	M,
	F
}
