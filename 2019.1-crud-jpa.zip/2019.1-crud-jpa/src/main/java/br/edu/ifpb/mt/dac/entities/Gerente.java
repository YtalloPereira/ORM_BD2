package br.edu.ifpb.mt.dac.entities;
import java.util.List;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@DiscriminatorValue("Gerente")
@Table(name = "TB_GERENTE")
public class Gerente extends Pessoa{
	
	private static final long serialVersionUID = 6598386989667400433L;
	
	@Column(name = "LOGIN", unique = true,nullable = false)
	private String login;
	@Column(name = "SENHA",nullable = false)
	private String senha;
	@OneToMany(mappedBy = "gerente", fetch = FetchType.EAGER,cascade = {CascadeType.PERSIST,CascadeType.REFRESH,CascadeType.REMOVE})
	private List<Funcionario> funcionarios;
	@OneToMany(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST,CascadeType.REFRESH})
	@JoinColumn(name = "GERENTE_FK")
	private List<Fornecedor> fornecedores;
	 
	  
	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public List<Funcionario> getFuncionarios() {
		return funcionarios;
	}

	public void setFuncionarios(List<Funcionario> funcionarios) {
		this.funcionarios = funcionarios;
	}

	public List<Fornecedor> getFornecedores() {
		return fornecedores;
	}

	public void setFornecedores(List<Fornecedor> fornecedores) {
		this.fornecedores = fornecedores;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(fornecedores, funcionarios, login, senha);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Gerente other = (Gerente) obj;
		return Objects.equals(fornecedores, other.fornecedores) && Objects.equals(funcionarios, other.funcionarios)
				&& Objects.equals(login, other.login) && Objects.equals(senha, other.senha);
	}
	

	
	@Override
	public String toString() {
		return "Tipo: Gerente\n"+"LOGIN: "+this.login+"\nSENHA: "+this.senha+ super.toString()+"\n\nFuncionarios:\n"+this.getFuncionarios().toString();
	}
	
}
