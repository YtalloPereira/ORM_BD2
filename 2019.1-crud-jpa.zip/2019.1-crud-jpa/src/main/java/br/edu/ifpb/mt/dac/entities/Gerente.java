package br.edu.ifpb.mt.dac.entities;

import java.util.ArrayList;

public class Gerente extends Pessoa{
	
	private ArrayList<Funcionario> funcionarios = new ArrayList<>();
	private ArrayList<Funcionario> fornecedores = new ArrayList<>();
	
	public Gerente() {
		
	}

	public ArrayList<Funcionario> getFuncionarios() {
		return funcionarios;
	}

	public void setFuncionarios(ArrayList<Funcionario> funcionarios) {
		this.funcionarios = funcionarios;
	}

	public ArrayList<Funcionario> getFornecedores() {
		return fornecedores;
	}

	public void setFornecedores(ArrayList<Funcionario> fornecedores) {
		this.fornecedores = fornecedores;
	}
	
}
