package br.edu.ifpb.mt.dac.entities;

public enum Situacao {
	EM_CONTRATO,
	DEMITIDO
}
