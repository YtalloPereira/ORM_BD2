package br.edu.ifpb.mt.dac.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import br.edu.ifpb.mt.dac.entities.Endereco;

public class EnderecoDAO extends DAO{
	public void save(Endereco endereco) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		try {
			em.persist(endereco);
			transaction.commit();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			if (transaction.isActive()) {
				transaction.rollback();
			}
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar salvar Endereço.", pe);
		} finally {
			em.close();
		}
	}
	public Endereco update(Endereco endereco) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		Endereco resultado = endereco;
		try {
			resultado = em.merge(endereco);
			transaction.commit();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			if (transaction.isActive()) {
				transaction.rollback();
			}
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar atualizar o endereço.", pe);
		} finally {
			em.close();
		}
		return resultado;
	}
	
	
	public Endereco getByID(int enderecoID) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		Endereco resultado = null;
		try {
			resultado = em.find(Endereco.class, enderecoID);
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar recuperar o Endereço com base no ID.", pe);
		} finally {
			em.close();
		}
		return resultado;
	}
	
	
	public void delete(Endereco endereco) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		try {
			endereco = em.find(Endereco.class, endereco.getId());
			em.remove(endereco);
			transaction.commit();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			if (transaction.isActive()) {
				transaction.rollback();
			}
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar remover o Endereço.", pe);
		} finally {
			em.close();
		}
	}
}


