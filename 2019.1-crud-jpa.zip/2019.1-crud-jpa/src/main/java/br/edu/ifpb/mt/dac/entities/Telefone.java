package br.edu.ifpb.mt.dac.entities;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TB_TELEFONE")
public class Telefone implements Serializable{

	private static final long serialVersionUID = 7584117442565848691L;
	
	@Id	
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer id;
	@Column(name = "NUMERO")
	private String numero;
	@OneToOne(fetch = FetchType.EAGER,mappedBy = "telefone")
	private Pessoa pessoa;
	
	public Telefone() {
		
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String string) {
		this.numero = string;
	}

	public Pessoa getPessoa() {
		return pessoa;
	}

	public void setPessoa(Pessoa pessoa) {
		this.pessoa = pessoa;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(id, numero, pessoa);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Telefone other = (Telefone) obj;
		
		return Objects.equals(id, other.id) && numero == other.numero && Objects.equals(pessoa, other.pessoa);
	}
}
