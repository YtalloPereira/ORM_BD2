package br.edu.ifpb.mt.dac.entities;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TB_TELEFONE")
public class Telefone implements Serializable{

	private static final long serialVersionUID = 7584117442565848691L;
	
	@Id	
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer id;
	@Column(name = "NUMERO")
	private String numero;
	
	public Telefone() {
		
	}

	public Integer getId() {
		return id;
	}


	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, numero);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Telefone other = (Telefone) obj;
		return Objects.equals(id, other.id) && Objects.equals(numero, other.numero);
	}

	@Override
	public String toString() {
		return super.toString()+"TELEFONE\nID: "+this.id+"\nNumero: "+this.numero;
	}


	

}
