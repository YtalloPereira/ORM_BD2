package br.edu.ifpb.mt.dac.entities;

import java.util.ArrayList;

public class ItemVenda {
	
	private Integer id;
	private int valorUnitário;
	private ArrayList<Produto> produtos = new ArrayList<>();
	
	public ItemVenda() {
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public int getValorUnitário() {
		return valorUnitário;
	}

	public void setValorUnitário(int valorUnitário) {
		this.valorUnitário = valorUnitário;
	}

	public ArrayList<Produto> getProdutos() {
		return produtos;
	}

	public void setProdutos(ArrayList<Produto> produtos) {
		this.produtos = produtos;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((produtos == null) ? 0 : produtos.hashCode());
		result = prime * result + valorUnitário;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ItemVenda other = (ItemVenda) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (produtos == null) {
			if (other.produtos != null)
				return false;
		} else if (!produtos.equals(other.produtos))
			return false;
		if (valorUnitário != other.valorUnitário)
			return false;
		return true;
	}
	
}
