package br.edu.ifpb.mt.dac;


import java.util.ArrayList;
import java.util.List;

import br.edu.ifpb.mt.dac.dao.FuncionarioDAO;
import br.edu.ifpb.mt.dac.dao.GerenteDAO;
import br.edu.ifpb.mt.dac.dao.PessoaDAO;
import br.edu.ifpb.mt.dac.dao.TelefoneDAO;
import br.edu.ifpb.mt.dac.entities.Funcionario;
import br.edu.ifpb.mt.dac.entities.Gerente;
import br.edu.ifpb.mt.dac.entities.Pessoa;
import br.edu.ifpb.mt.dac.entities.Situacao;
import br.edu.ifpb.mt.dac.entities.Telefone;

public class MainUpdate {

	public static void main(String[] args) throws DacException {
		GerenteDAO dao = new GerenteDAO();
		TelefoneDAO tellDao = new TelefoneDAO();
		try {
			List<Telefone> tellGerente = new ArrayList<>();
			Telefone telefoneGerente = new Telefone();
			telefoneGerente.setNumero("(83)88888-8888");
			tellGerente.add(telefoneGerente);
			//Recuperando o funcionario que será atualizado!
			//Pessoa gerente = dao.getByID(1);
			Telefone tell = tellDao.getByID(21);
	
			//System.out.println(gerente.getTelefone());

			// Atualizando oas Dados do funcionario!!
			//gerente.setTelefone(tellGerente);
			

			//dao.update((Gerente) gerente);
			tell.setNumero("(83)88888-8888");
			tellDao.update(tell);

			System.out.println(tell.getNumero());
		} finally {
			dao.close();
		}
	}

}
