package br.edu.ifpb.mt.dac;


import br.edu.ifpb.mt.dac.dao.FuncionarioDAO;

import br.edu.ifpb.mt.dac.entities.Funcionario;
import br.edu.ifpb.mt.dac.entities.Situacao;

public class MainUpdate {

	public static void main(String[] args) throws DacException {
		FuncionarioDAO dao = new FuncionarioDAO();
		try {
			
			//Recuperando o funcionario que será atualizado!
			Funcionario funcionario = dao.getByID(10);
			

			System.out.println(funcionario);

			// Atualizando oas Dados do funcionario!!
			funcionario.setEmail("novo@gmail.com");
			funcionario.setSituacao(Situacao.DEMITIDO);

			dao.update(funcionario);

			System.out.println(funcionario);
		} finally {
			dao.close();
		}
	}

}
