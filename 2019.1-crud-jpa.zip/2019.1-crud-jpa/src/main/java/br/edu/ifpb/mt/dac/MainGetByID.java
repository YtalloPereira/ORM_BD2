package br.edu.ifpb.mt.dac;

import java.util.Date;

import br.edu.ifpb.mt.dac.dao.PessoaDAO;
import br.edu.ifpb.mt.dac.dao.UserDAO;
import br.edu.ifpb.mt.dac.entities.Funcionario;
import br.edu.ifpb.mt.dac.entities.Pessoa;
import br.edu.ifpb.mt.dac.entities.User;

public class MainGetByID {

	public static void main(String[] args) throws DacException {
		PessoaDAO dao = new PessoaDAO();
		try {
			// Primeiro salvar
			Pessoa user = new Funcionario();
//
//			user.setDataNasc(new Date());
//			user.setEmail("func@hotmail.com");
//			user.setNome("Fulano");
//	
//			dao.save(user);

			// Depois recuperar pelo identificador

			Pessoa resultado = dao.getByID(8);

			System.out.println(user.equals(resultado));
			System.out.println(resultado);
		} finally {
			dao.close();
		}
	}

}
