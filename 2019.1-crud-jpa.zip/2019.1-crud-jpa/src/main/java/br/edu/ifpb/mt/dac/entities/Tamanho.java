package br.edu.ifpb.mt.dac.entities;

public enum Tamanho {
	P,
	M,
	G,
	XG
}
