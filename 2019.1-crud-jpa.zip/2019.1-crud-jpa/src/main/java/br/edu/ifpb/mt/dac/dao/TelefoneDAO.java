package br.edu.ifpb.mt.dac.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import br.edu.ifpb.mt.dac.entities.Telefone;

public class TelefoneDAO extends DAO{
	
	public void save(Telefone telefone) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		try {
			em.persist(telefone);
			transaction.commit();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			if (transaction.isActive()) {
				transaction.rollback();
			}
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar salvar Telefone.", pe);
		} finally {
			em.close();
		}
	}
	public Telefone update(Telefone telefone) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		Telefone resultado = telefone;
		try {
			resultado = em.merge(telefone);
			transaction.commit();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			if (transaction.isActive()) {
				transaction.rollback();
			}
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar atualizar o usuário.", pe);
		} finally {
			em.close();
		}
		return resultado;
	}
	
	
	public Telefone getByID(int tellID) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		Telefone resultado = null;
		try {
			resultado = em.find(Telefone.class, tellID);
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar recuperar o usuário com base no ID.", pe);
		} finally {
			em.close();
		}
		return resultado;
	}
	
	public void delete(Telefone telefone) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		try {
			telefone = em.find(Telefone.class, telefone.getId());
			em.remove(telefone);
			transaction.commit();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			if (transaction.isActive()) {
				transaction.rollback();
			}
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar remover o usuário.", pe);
		} finally {
			em.close();
		}
	}
	public List<Telefone> getAll() throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		List<Telefone> resultado = null;
		try {
			TypedQuery<Telefone> query = em.createQuery("SELECT u FROM Telefone u", Telefone.class);
			resultado = query.getResultList();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar recuperar todos os usuários.", pe);
		} finally {
			em.close();
		}
		return resultado;
	}
	
}
