package br.edu.ifpb.mt.dac.entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TB_PRODUTO")
public class Produto implements Serializable {
	
	private static final long serialVersionUID = -7587169506920227223L;
	@Id
	@Column(name = "ID")
	private Integer id;
	@Column(name = "VALOR_COMPRA")
	private long valorCompra;
	@Column(name = "VALOR_VENDA")
	private long valorVenda;
	@Column(name = "DESCRIÇÃO")
	private String descricao;
	@Column(name = "QUANTIDADE")
	private int quatidade;
	@Column(name = "NOME")
	private String nome;
	@Column(name = "RECIDO")
	private String tecido;
	@Column(name = "TAMANHO")
	@Enumerated(EnumType.STRING)
	private Tamanho tamanho;
	private String fabricante;
	@Column(name = "SEXO")
	@Enumerated(EnumType.STRING)
	private Sexo sexo;
	@Column(name = "FORNECEDOR")
	@ManyToOne
	@JoinColumn(name = "TB_FORNECEDOR_FK")
	private Fornecedor fornecedor;
	
	public Produto(){
		
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public long getValorCompra() {
		return valorCompra;
	}
	public void setValorCompra(long valorCompra) {
		this.valorCompra = valorCompra;
	}
	public long getValorVenda() {
		return valorVenda;
	}
	public void setValor_venda(long valorVenda) {
		this.valorVenda = valorVenda;
	}
	public String getDescrição() {
		return descricao;
	}
	public void setDescrição(String descricao) {
		this.descricao = descricao;
	}
	public int getQuatidade() {
		return quatidade;
	}
	public void setQuatidade(int quatidade) {
		this.quatidade = quatidade;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getTecido() {
		return tecido;
	}
	public void setTecido(String tecido) {
		this.tecido = tecido;
	}
	public Tamanho getTamanho() {
		return tamanho;
	}
	public void setTamanho(Tamanho tamanho) {
		this.tamanho = tamanho;
	}
	public String getFabricante() {
		return fabricante;
	}
	public void setFabricante(String fabricante) {
		this.fabricante = fabricante;
	}
	public Sexo getSexo() {
		return sexo;
	}
	public void setSexo(Sexo sexo) {
		this.sexo = sexo;
	}

}
