package br.edu.ifpb.mt.dac.entities;

public class Produto {
	
	private Integer id;
	private long valorCompra;
	private long valorVenda;
	private String descrição;
	private int quatidade;
	private String nome;
	private String tecido;
	private long tamanho;
	private String fabricante;
	private Sexo sexo;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public long getValorCompra() {
		return valorCompra;
	}
	public void setValorCompra(long valorCompra) {
		this.valorCompra = valorCompra;
	}
	public long getValorVenda() {
		return valorVenda;
	}
	public void setValor_venda(long valorVenda) {
		this.valorVenda = valorVenda;
	}
	public String getDescrição() {
		return descrição;
	}
	public void setDescrição(String descrição) {
		this.descrição = descrição;
	}
	public int getQuatidade() {
		return quatidade;
	}
	public void setQuatidade(int quatidade) {
		this.quatidade = quatidade;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getTecido() {
		return tecido;
	}
	public void setTecido(String tecido) {
		this.tecido = tecido;
	}
	public long getTamanho() {
		return tamanho;
	}
	public void setTamanho(long tamanho) {
		this.tamanho = tamanho;
	}
	public String getFabricante() {
		return fabricante;
	}
	public void setFabricante(String fabricante) {
		this.fabricante = fabricante;
	}
	public Sexo getSexo() {
		return sexo;
	}
	public void setSexo(Sexo sexo) {
		this.sexo = sexo;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((descrição == null) ? 0 : descrição.hashCode());
		result = prime * result + ((fabricante == null) ? 0 : fabricante.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		result = prime * result + quatidade;
		result = prime * result + ((sexo == null) ? 0 : sexo.hashCode());
		result = prime * result + (int) (tamanho ^ (tamanho >>> 32));
		result = prime * result + ((tecido == null) ? 0 : tecido.hashCode());
		result = prime * result + (int) (valorCompra ^ (valorCompra >>> 32));
		result = prime * result + (int) (valorVenda ^ (valorVenda >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Produto other = (Produto) obj;
		if (descrição == null) {
			if (other.descrição != null)
				return false;
		} else if (!descrição.equals(other.descrição))
			return false;
		if (fabricante == null) {
			if (other.fabricante != null)
				return false;
		} else if (!fabricante.equals(other.fabricante))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (quatidade != other.quatidade)
			return false;
		if (sexo != other.sexo)
			return false;
		if (tamanho != other.tamanho)
			return false;
		if (tecido == null) {
			if (other.tecido != null)
				return false;
		} else if (!tecido.equals(other.tecido))
			return false;
		if (valorCompra != other.valorCompra)
			return false;
		if (valorVenda != other.valorVenda)
			return false;
		return true;
	}
	
	
	
}
