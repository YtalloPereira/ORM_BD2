package br.edu.ifpb.mt.dac.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import br.edu.ifpb.mt.dac.entities.Gerente;

public class GerenteDAO extends DAO{

	public void save(Gerente gerente) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		try {
			em.persist(gerente);
			transaction.commit();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			if (transaction.isActive()) {
				transaction.rollback();
			}
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar salvar Gerente.", pe);
		} finally {
			em.close();
		}
	}
	
	public Gerente getByID(int gerenteID) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		Gerente resultado = null;
		try {
			resultado = em.find(Gerente.class, gerenteID);
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar recuperar o Gerente com base no ID.", pe);
		} finally {
			em.close();
		}
		return resultado;
	}
	
	public Gerente update(Gerente gerente) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		Gerente resultado = gerente;
		try {
			resultado = em.merge(gerente);
			transaction.commit();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			if (transaction.isActive()) {
				transaction.rollback();
			}
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar atualizar o Gerente.", pe);
		} finally {
			em.close();
		}
		return resultado;
	}
	public void delete(Gerente gerente) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		try {
			gerente = em.find(Gerente.class, gerente.getId());
			em.remove(gerente);
			transaction.commit();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			if (transaction.isActive()) {
				transaction.rollback();
			}
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar remover o Gerente.", pe);
		} finally {
			em.close();
		}
	}
	public List<Gerente> getAll() throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		List<Gerente> resultado = null;
		try {
			TypedQuery<Gerente> query = em.createQuery("SELECT u FROM Gerente u", Gerente.class);
			resultado = query.getResultList();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar recuperar todos os usuários.", pe);
		} finally {
			em.close();
		}
		return resultado;
	}
}
