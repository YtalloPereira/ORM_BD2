package br.edu.ifpb.mt.dac.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import br.edu.ifpb.mt.dac.entities.Pessoa;

public class PessoaDAO extends DAO {
	public void save(Pessoa pessoa) throws PersistenciaDacException {
		EntityManager em = getEntityManager();
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		try {
			em.persist(pessoa);
			transaction.commit();
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			if (transaction.isActive()) {
				transaction.rollback();
			}
			throw new PersistenciaDacException("Ocorreu algum erro ao tentar salvar pessoa.", pe);
		} finally {
			em.close();
		}
	}
}
