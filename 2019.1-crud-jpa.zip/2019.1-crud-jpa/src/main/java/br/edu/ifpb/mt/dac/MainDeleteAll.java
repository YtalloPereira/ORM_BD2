package br.edu.ifpb.mt.dac;

import java.util.Iterator;
import java.util.List;
import br.edu.ifpb.mt.dac.dao.ClienteDAO;
import br.edu.ifpb.mt.dac.dao.GerenteDAO;
import br.edu.ifpb.mt.dac.dao.PessoaDAO;
import br.edu.ifpb.mt.dac.entities.Cliente;
import br.edu.ifpb.mt.dac.entities.Gerente;
import br.edu.ifpb.mt.dac.entities.Pessoa;


public class MainDeleteAll {

	public static void main(String[] args) throws DacException {
		GerenteDAO daoGerente = new GerenteDAO();
		ClienteDAO daoCliente = new ClienteDAO();
		try {
//			List<Cliente> clientes = daoCliente.getAll();
//			for (Cliente c : clientes) {
//				daoCliente.delete(c);
//			}
			List<Gerente> gerentes = daoGerente.getAll();
			for (Gerente g : gerentes) {
				daoGerente.delete(g);
			}
			
		} finally {
			daoCliente.close();
			daoGerente.close();
		}
		
	}

}
