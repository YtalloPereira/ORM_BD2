package br.edu.ifpb.mt.dac;

import java.util.Iterator;
import java.util.List;

import br.edu.ifpb.mt.dac.dao.ClienteDAO;
import br.edu.ifpb.mt.dac.dao.PessoaDAO;
import br.edu.ifpb.mt.dac.dao.UserDAO;
import br.edu.ifpb.mt.dac.entities.Cliente;
import br.edu.ifpb.mt.dac.entities.Pessoa;
import br.edu.ifpb.mt.dac.entities.User;

public class MainDeleteAll {

	public static void main(String[] args) throws DacException {

		ClienteDAO cliente = new ClienteDAO();
		PessoaDAO pDao = new PessoaDAO();
		List<Pessoa> pessoa = pDao.getAll();
		
		
		for (Pessoa pessoas : pessoa) {
			if(pessoas.getId() == (cliente.getByID(pessoas.getId()).getId())) {
				pDao.delete(pessoas);
			}
		}
		
	}

}
