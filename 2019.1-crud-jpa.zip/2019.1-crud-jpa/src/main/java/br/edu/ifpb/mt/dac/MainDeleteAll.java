package br.edu.ifpb.mt.dac;

import java.util.List;
import br.edu.ifpb.mt.dac.dao.UserDAO;
import br.edu.ifpb.mt.dac.entities.User;

public class MainDeleteAll {

	public static void main(String[] args) throws DacException {
//		EstoqueDAO dao = new EstoqueDAO();
//		try {
//			List<Estoque> usuarios = dao.getAll();
//			for (Estoque usuario : usuarios) {
//				dao.delete(usuario);
//			}
//		} finally {
//			dao.close();
//		}
	}

}
