package br.edu.ifpb.mt.dac;

import java.util.Date;
import java.util.List;

import br.edu.ifpb.mt.dac.dao.FuncionarioDAO;
import br.edu.ifpb.mt.dac.dao.PessoaDAO;
import br.edu.ifpb.mt.dac.dao.ProdutoDAO;
import br.edu.ifpb.mt.dac.dao.UserDAO;
import br.edu.ifpb.mt.dac.entities.Funcionario;
import br.edu.ifpb.mt.dac.entities.Pessoa;
import br.edu.ifpb.mt.dac.entities.User;

public class MainDelete {

	public static void main(String[] args) throws DacException {
		FuncionarioDAO dao = new FuncionarioDAO();
		PessoaDAO daoP = new PessoaDAO();
		try {
			// Primeiro salvar
			List<Funcionario> func = dao.getAll();

			

			// Depois apagar

			

			
		} finally {
			dao.close();
		}
	}

}
