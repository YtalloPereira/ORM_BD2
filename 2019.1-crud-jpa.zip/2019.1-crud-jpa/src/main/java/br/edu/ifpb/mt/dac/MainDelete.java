package br.edu.ifpb.mt.dac;

import java.util.Date;

import br.edu.ifpb.mt.dac.dao.EstoqueDAO;
import br.edu.ifpb.mt.dac.dao.ProdutoDAO;
import br.edu.ifpb.mt.dac.dao.UserDAO;
import br.edu.ifpb.mt.dac.entities.Estoque;
import br.edu.ifpb.mt.dac.entities.User;

public class MainDelete {

	public static void main(String[] args) throws DacException {
		ProdutoDAO dao = new ProdutoDAO();
		EstoqueDAO estq = new EstoqueDAO();
		try {
			// Primeiro salvar
			Estoque est= estq.getByID(1);
			est.setQuantidade(est.getQuantidade()-1);

			

			// Depois apagar

			dao.delete(dao.getByID(17));
			estq.update(est);

			
		} finally {
			dao.close();
		}
	}

}
