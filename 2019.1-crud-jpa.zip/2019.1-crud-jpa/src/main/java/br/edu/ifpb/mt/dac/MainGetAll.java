package br.edu.ifpb.mt.dac;

import java.util.List;

import br.edu.ifpb.mt.dac.dao.PessoaDAO;
import br.edu.ifpb.mt.dac.entities.Pessoa;


public class MainGetAll {

	public static void main(String[] args) throws DacException {

		PessoaDAO dao = new PessoaDAO();
		try {
			List<Pessoa> usuarios = dao.getAll();

			for (Pessoa user : usuarios) {
				System.out.println(user.toString());
				System.out.println("---------------------------------------------------");
			}

		} finally {
			dao.close();
		}
		
		
	}

}
