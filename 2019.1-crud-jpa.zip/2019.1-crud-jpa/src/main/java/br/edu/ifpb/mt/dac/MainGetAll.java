package br.edu.ifpb.mt.dac;

import java.util.List;

import br.edu.ifpb.mt.dac.dao.PessoaDAO;
import br.edu.ifpb.mt.dac.dao.TelefoneDAO;
import br.edu.ifpb.mt.dac.entities.Pessoa;


public class MainGetAll {

	public static void main(String[] args) throws DacException {

		TelefoneDAO dao = new TelefoneDAO();
		try {
			List<Telefone> usuarios = dao.getTelefoneForID(1);

			for (Telefone user : usuarios) {
				System.out.println(user.toString());
				System.out.println("---------------------------------------------------");
			}

		} finally {
			dao.close();
		}
		
		
	}

}
