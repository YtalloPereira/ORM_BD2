package br.edu.ifpb.mt.dac.entities;

import java.util.ArrayList;
import java.util.Date;

public class Venda {
	
	private Integer id;
	private Date dataVenda;
	private long valorTotal;
	private ArrayList<ItemVenda> itensVenda = new ArrayList<>();
	
	public Venda() {
		
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Date getDataVenda() {
		return dataVenda;
	}
	public void setDataVenda(Date dataVenda) {
		this.dataVenda = dataVenda;
	}
	public long getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(long valorTotal) {
		this.valorTotal = valorTotal;
	}
	public ArrayList<ItemVenda> getItensVenda() {
		return itensVenda;
	}
	public void setItensVenda(ArrayList<ItemVenda> itensVenda) {
		this.itensVenda = itensVenda;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dataVenda == null) ? 0 : dataVenda.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((itensVenda == null) ? 0 : itensVenda.hashCode());
		result = prime * result + (int) (valorTotal ^ (valorTotal >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Venda other = (Venda) obj;
		if (dataVenda == null) {
			if (other.dataVenda != null)
				return false;
		} else if (!dataVenda.equals(other.dataVenda))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (itensVenda == null) {
			if (other.itensVenda != null)
				return false;
		} else if (!itensVenda.equals(other.itensVenda))
			return false;
		if (valorTotal != other.valorTotal)
			return false;
		return true;
	}
	
	
	
}
