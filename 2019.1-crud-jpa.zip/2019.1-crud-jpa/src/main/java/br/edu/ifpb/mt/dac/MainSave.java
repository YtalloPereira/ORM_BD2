package br.edu.ifpb.mt.dac;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import br.edu.ifpb.mt.dac.dao.EnderecoDAO;
import br.edu.ifpb.mt.dac.dao.FornecedorDAO;
import br.edu.ifpb.mt.dac.dao.PessoaDAO;
import br.edu.ifpb.mt.dac.dao.ProdutoDAO;
import br.edu.ifpb.mt.dac.dao.TelefoneDAO;
import br.edu.ifpb.mt.dac.dao.VendaDAO;
import br.edu.ifpb.mt.dac.entities.Cliente;
import br.edu.ifpb.mt.dac.entities.Endereco;
import br.edu.ifpb.mt.dac.entities.Fornecedor;
import br.edu.ifpb.mt.dac.entities.Funcionario;
import br.edu.ifpb.mt.dac.entities.Gerente;
import br.edu.ifpb.mt.dac.entities.Pessoa;
import br.edu.ifpb.mt.dac.entities.Produto;
import br.edu.ifpb.mt.dac.entities.Sexo;
import br.edu.ifpb.mt.dac.entities.Situacao;
import br.edu.ifpb.mt.dac.entities.Tamanho;
import br.edu.ifpb.mt.dac.entities.Telefone;
import br.edu.ifpb.mt.dac.entities.Venda;


public class MainSave {

	public static void main(String[] args) throws DacException {
		
		PessoaDAO daoPessoa = new PessoaDAO();
		EnderecoDAO endDao = new EnderecoDAO();
		ProdutoDAO prodDao = new ProdutoDAO();
		FornecedorDAO fornDAO = new FornecedorDAO();
		TelefoneDAO telDAO = new TelefoneDAO();
		VendaDAO vendaDAO = new VendaDAO();
		
		
		
		try {
			List<Funcionario> funcionarios = new ArrayList<Funcionario>();
			Funcionario funcionario = new Funcionario();
			funcionario.setCargo("Vendedor");
			funcionario.setCpf("455.455.455-2");
			funcionario.setDataNasc(new Date());
			funcionario.setNome("Fulano");
			funcionario.setLogin("Fulano_fulano");
			funcionario.setSalario(1212);
			funcionario.setSenha("123456");
			funcionario.setSituacao(Situacao.EM_CONTRADO);
			funcionario.setEmail("func@hotmail.com");
			
			List<Produto>produtos = new ArrayList<Produto>();
			Produto  produto = new Produto();
			produto.setDescricao("Camisa legal");
			produto.setFabricante("Adidas B)");
			produto.setNome("camisa branca generica");
			produto.setQuatidade(1);
			produto.setSexo(Sexo.M);
			produto.setTamanho(Tamanho.G);
			produto.setTecido("Pano");
			produto.setValor_venda(345);
			produto.setValorCompra(200);
			produtos.add(produto);
			prodDao.save(produto);
			
			List<Venda>vendas = new ArrayList<Venda>();
			Venda venda = new Venda();
			venda.setDataVenda(new Date(20220722));
			venda.setValorTotal(345);
			venda.setProdutos(produtos);
			vendas.add(venda);
			vendaDAO.save(venda);
			
			
			Endereco enderecoCliente = new Endereco();
			enderecoCliente.setBairro("São joão");
			enderecoCliente.setCEP("678333-999");
			enderecoCliente.setComplemento("ao lado da lanchonete  2 irmaos");
			enderecoCliente.setNumero("789");
			enderecoCliente.setRua("Ruas das Almas");
			endDao.save(enderecoCliente);
			
			List<Cliente> clientes = new ArrayList<Cliente>();
			Cliente cliente = new Cliente();
			cliente.setCpf("234.345.678-6");
			cliente.setDataNasc(new Date("1980/07/22"));
			cliente.setEmail("cliente@hotmail.com");
			cliente.setNome("Beltrano");
			cliente.setEndereco(enderecoCliente);
		
			
			Endereco enderecoGerente = new Endereco();
			enderecoGerente.setBairro("São Paulo");
			enderecoGerente.setCEP("55555-000");
			enderecoGerente.setComplemento("Ao lado da igreja católica");
			enderecoGerente.setNumero("45");
			enderecoGerente.setRua("Rua das Pedras");
			endDao.save(enderecoGerente);
			
			
			Endereco endFuncionario = new Endereco();
			endFuncionario.setBairro("São José");
			endFuncionario.setCEP("55333-000");
			endFuncionario.setComplemento("Ao lado da igreja envangelica");
			endFuncionario.setNumero("66");
			endFuncionario.setRua("Rua das Lesmas");
			endDao.save(endFuncionario);
			funcionario.setEndereco(endFuncionario);
			
			Gerente gerente = new Gerente();
			gerente.setCpf("555.555.444-0");
			gerente.setDataNasc(new Date());
			gerente.setEmail("Email@gmail.com");
			gerente.setEndereco(enderecoGerente);
			gerente.setLogin("nome_sobrnome");
			gerente.setNome("Sicrano");
			gerente.setSenha("123");
			
			clientes.add(cliente);
			gerente.setFuncionarios(funcionarios);
			funcionario.setClientes(clientes);
			funcionario.setGerente(gerente);
			funcionario.setVendas(vendas);
			funcionarios.add(funcionario);
			
			daoPessoa.save(cliente);
			daoPessoa.save(gerente);
			daoPessoa.save(funcionario);
			
			//daoPessoa.update(gerente);
			
//			daoPessoa.save(cliente);
//			daoPessoa.save(gerente);
//			funcionario.setGerente(gerente);
//			funcionarios.add(funcionario);
//			clientes.add(cliente);
//			funcionario.setClientes(clientes);
//			gerente.setFuncionarios(funcionarios);
//			daoPessoa.save(funcionario);
//			daoPessoa.update(gerente);
		
			

//			Gerente gerente = new Gerente();
//			gerente.setCpf("555.555.555-5");
//			gerente.setDataNasc(new Date());
//			gerente.setEmail("email@gmail.com");
//			gerente.setNome("Fulano");
//			Telefone tel = new Telefone();
//			tel.setNumero("263237237");
//			gerente.setTelefone(tel);
//			gerente.setSenha("123");
//			Endereco novo = new Endereco();
//			novo.setBairro("Nome legal");
//			novo.setCEP("555555555");
//			novo.setComplemento("Ao lado da igreja");
//			novo.setNúmero("25");
//			novo.setRua("Rua das Pedras");
//			gerente.setEndereco(novo);
//			gerente.setLogin("Fulano_Sobrenome");
//			
//			List<Funcionario> funcionarios = new ArrayList<Funcionario>();
//			
//			Endereco novoEnd = new Endereco();
//			novoEnd.setBairro("Nome legal 222");
//			novoEnd.setCEP("555555555-000");
//			novoEnd.setComplemento("Ao lado da igreja catolica");
//			novoEnd.setNúmero("277");
//			novoEnd.setRua("Rua das Lesmas");
//			
//			Pessoa novoFunc = new Funcionario();
//			novoFunc.setNome("Sicrano");
//			novoFunc.setCpf("555.555.555-0");
//			novoFunc.setDataNasc(new Date());
//			novoFunc.setEmail("email@hotmail.com");
//			Telefone telF = new Telefone();
//			telF.setNumero("263237237");
//			novoFunc.setTelefone(telF);
//			novoFunc.setEndereco(novo);
//			((Funcionario) novoFunc).setCargo("Vendendor");
//			((Funcionario) novoFunc).setGerente(gerente);
//			((Funcionario) novoFunc).setLogin("EU_123");
//			((Funcionario) novoFunc).setSenha("1234");
//			((Funcionario) novoFunc).setSalario(22222);
//			funcionarios.add((Funcionario) novoFunc);
//			
//			novoFunc.setEndereco(novoEnd);
//			gerente.setFuncionarios(funcionarios);
//			
//			
//			
//			Telefone telC = new Telefone();
//			telC.setNumero("(82)92392-7237");
//			Endereco enderecoC = new Endereco();
//			enderecoC.setRua("Rua Do Gás");
//			enderecoC.setBairro("Centro");
//			enderecoC.setNúmero("12");
//			enderecoC.setCEP("23333-333");
//			enderecoC.setComplemento("Casa");
//			Pessoa cliente = new Cliente();
//			cliente.setNome("iiiii");
//			cliente.setDataNasc(new Date());
//			cliente.setCpf("125.812.128-12");
//			cliente.setEmail("iiiii@gmail.com");
//			cliente.setTelefone(telF);
//			cliente.setEndereco(enderecoC);
//			
//			List<Fornecedor> forn = new ArrayList<>();
//			List<Produto> prod = new ArrayList<>();
//			Produto produto = new Produto();
//			produto.setNome("Camisa");
//			produto.setSexo(Sexo.M);
//			produto.setDescrição("kasnansansasas");
//			produto.setFabricante("aaaa");
//			produto.setQuatidade(200);
//			produto.setTamanho(Tamanho.M);
//			produto.setTecido("Algodão");
//			produto.setValorCompra(15);
//			produto.setValor_venda(30);
//			prod.add(produto);
//			
//			Fornecedor fornecedor = new Fornecedor();
//			fornecedor.setNome("Adidas");
//			fornecedor.setCNPJ("51254154256/1212");
//			fornecedor.setEmail("adidas.com");
//			fornecedor.setTelefone("(22)23233-3322");
//			fornecedor.setProdutos(prod);
//			produto.setFornecedor(fornecedor);
//			forn.add(fornecedor);
//			fornDAO.save(fornecedor);
//			gerente.setFornecedores(forn);
//			
//			
//			
//			
//			prodDao.save(produto);
//			
//			System.out.println(gerente);
//			telDAO.save(telC);		
//			telDAO.save(tel);
//			telDAO.save(telF);
//			endDao.save(novo);
//			endDao.save(novoEnd);
//			endDao.save(enderecoC);			
//			daoPessoa.save(gerente);
//			daoPessoa.save(cliente);
//			daoPessoa.save(novoFunc);
//			
//			
//			
//					
//			
//			
//			
//			
//			
//			System.out.println(gerente);
//			
			System.out.println(gerente);
			
		} finally {
			daoPessoa.close();
		}
	}

}
