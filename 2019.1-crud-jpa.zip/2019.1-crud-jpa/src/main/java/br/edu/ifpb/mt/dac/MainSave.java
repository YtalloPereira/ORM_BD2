package br.edu.ifpb.mt.dac;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import br.edu.ifpb.mt.dac.dao.PessoaDAO;
import br.edu.ifpb.mt.dac.dao.UserDAO;
import br.edu.ifpb.mt.dac.entities.Endereco;
import br.edu.ifpb.mt.dac.entities.Funcionario;
import br.edu.ifpb.mt.dac.entities.Gerente;


public class MainSave {

	public static void main(String[] args) throws DacException {
		UserDAO dao = new UserDAO();
		PessoaDAO daoPessoa = new PessoaDAO();
		try {
//			User user = new User();
//
//			user.setBirthday(new Date());
//			user.setEmail("email@gmail.com");
//			user.setFirstName("Sicrano");
//			user.setLastName("Silva");
//
//			System.out.println(user);
//			
//			dao.save(user);
//
//			System.out.println(user);
			Gerente pessoa = new Gerente();
			pessoa.setCpf("555.555.555-5");
			pessoa.setDataNasc(new Date());
			pessoa.setEmail("email@gmail.com");
			pessoa.setNome("Fulano");
			pessoa.setTelefone("5555-5555");
			pessoa.setSenha("123");
			Endereco novo = new Endereco();
			novo.setBairro("Nome legal");
			novo.setCEP("555555555");
			novo.setComplemento("Ao lado da igreja");
			novo.setNúmero("25");
			novo.setRua("Rua das Pedras");
			pessoa.setEndereco(novo);
			pessoa.setLogin("Fulano_Sobrenome");
			
			List<Funcionario> funcionarios = new ArrayList<Funcionario>();
			Funcionario novoFunc = new Funcionario();
			novoFunc.setNome("Sicrano");
			novoFunc.setCpf("555.555.555-0");
			novoFunc.setDataNasc(new Date());
			novoFunc.setEmail("email@hotmail.com");
			novoFunc.setTelefone("4444-5555");
			novoFunc.setCargo("Vendendor");
			novoFunc.setGerente(pessoa);
			novoFunc.setLogin("EU_123");
			novoFunc.setSenha("1234");
			
			Endereco novoEnd = new Endereco();
			novoEnd.setBairro("Nome legal 222");
			novoEnd.setCEP("555555555-000");
			novoEnd.setComplemento("Ao lado da igreja catolica");
			novoEnd.setNúmero("277");
			novoEnd.setRua("Rua das Lesmas");
			
			novoFunc.setEndereco(novo);
			funcionarios.add(novoFunc);
			pessoa.setFuncionarios(funcionarios);
			
			
			
			
			System.out.println(pessoa);
			daoPessoa.save(pessoa);
			System.out.println(pessoa);
			
		} finally {
			dao.close();
		}
	}

}
